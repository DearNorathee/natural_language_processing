from natural_language_processing.local_tts import *
from natural_language_processing.word_freq import *
from natural_language_processing.conjugator_pt import *
__version__ = "0.1.0"